# Items

This folder contains additional items that you can use in the challenges. 

To add an item, just drag it with your mouse from this folder into the challenge.

To remove an item from a challenge left click it once with the mouse to select it
and then press the "Delete" key on your keyboard (or Cmd + Backspace if you are
on a Mac). A dialog will show and ask you if you really want to delete this node,
press "OK" to delete it or "Cancel" to abort this.

If you accidentally delete something you didn't want to delete you can press
Ctrl+Z (or Cmd + Z if you are on a Mac) to undo your last action. 

In case something goes totally wrong, you can always re-download the example
project, so don't be afraid to try a few things out.
